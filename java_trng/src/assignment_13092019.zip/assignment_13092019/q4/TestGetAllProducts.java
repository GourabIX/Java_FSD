package assignment_13092019.q4;

public class TestGetAllProducts {

	public static void main(String[] args) {
		
		GetAllProducts getterAll = new GetAllProducts();
		getterAll.allProductGetter();

	}

}
